from hashlib import sha3_512 
from secret import flag
import os, signal

"""
Description: 
In post quantum cryptography, hash-based cryptography is a type of public-key cryptography that uses hash functions to provide security. 
It is considered to be resistant to attacks from quantum computers, which can break many traditional cryptographic systems. 
"""

def proof_of_work():
    print("gimme a pairs of (x, y, z) that sha3_512(x) == shae3_512(y) == sha3_512(z)")
    print("x != y != z")
    x = input("x: ")
    y = input("y: ")
    z = input("z: ")
    assert len(x) == len(y) == len(z) == 128
    if len(set([x, y, z])) != 3:
        print("x, y, z must be different")
        return False

    if len(set([sha3_512(bytes.fromhex(i)).hexdigest() for i in [x, y, z]])) != 1:
        print("hashes are not equal")
        return False
    
    print("good job")
    return True

if not proof_of_work():
    exit()

signal.alarm(60)

def hash_based_world(): 
    suffix = os.urandom(8)
    print(f"gimme 8 msgs, their hexes are ends with {suffix.hex()}") 
    pairs = []
    for _ in range(8):
        msg = input("msg: ")
        if not msg.endswith(suffix.hex()):
            print("wrong msg")
            return False
        pairs.append(bytes.fromhex(msg))
    n = 4722366482869645213711
    if sum([int.from_bytes(sha3_512(i).digest(), 'big') for i in pairs]) % n == 0:
        print("good job") 
        return True
    return False

if not hash_based_world():
    print("bye")
    exit()

print(flag)